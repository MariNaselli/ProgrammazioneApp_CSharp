﻿
namespace pin.dependencyinjection.Model
{
    public interface IWeapon
    {
        int? Strike();
    }
}
