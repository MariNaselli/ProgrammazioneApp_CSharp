﻿
namespace pin.dependencyinjection.Model
{
    public interface IArmor
    {
        bool AbsorbDamage(int damage);
    }
}
